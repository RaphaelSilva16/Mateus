# Site de fotos

Site estático, sem dependências: três fotos inteiras, fundo cinza escuro, troca a cada 2 segundos e fade de 300 ms.

## Enviar ao GitHub

1. Extraia o arquivo site-github.zip.
2. Envie o conteúdo extraído para a raiz do repositório, preservando a pasta imagens. O index.html deve ficar na raiz, sem uma pasta extra acima dele.
3. Confirme o envio dos arquivos no GitHub.

## Publicar no GitHub Pages

1. No repositório, abra Settings > Pages.
2. Em Source, selecione Deploy from a branch.
3. Selecione a branch que contém os arquivos (normalmente main), a pasta /(root) e clique em Save.
4. Aguarde a publicação; o endereço será mostrado na seção Pages.

Documentação: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

Para visualizar no computador, abra index.html no navegador.
